/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.datastorage;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Siyanda
 */
public class DatastorageTest {
    
    public DatastorageTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class Datastorage.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Datastorage.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displaySentMessages method, of class Datastorage.
     */
    @Test
    public void testDisplaySentMessages() {
        System.out.println("displaySentMessages");
        Datastorage instance = new Datastorage();
        instance.displaySentMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLongestMessage method, of class Datastorage.
     */
    @Test
    public void testGetLongestMessage() {
        System.out.println("getLongestMessage");
        Datastorage instance = new Datastorage();
        String expResult = "";
        String result = instance.getLongestMessage();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchMessageByID method, of class Datastorage.
     */
    @Test
    public void testSearchMessageByID() {
        System.out.println("searchMessageByID");
        String searchID = "";
        Datastorage instance = new Datastorage();
        String expResult = "";
        String result = instance.searchMessageByID(searchID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchMessagesByRecipient method, of class Datastorage.
     */
    @Test
    public void testSearchMessagesByRecipient() {
        System.out.println("searchMessagesByRecipient");
        String recipient = "";
        Datastorage instance = new Datastorage();
        List<String> expResult = null;
        List<String> result = instance.searchMessagesByRecipient(recipient);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteMessageByHash method, of class Datastorage.
     */
    @Test
    public void testDeleteMessageByHash() {
        System.out.println("deleteMessageByHash");
        String hash = "";
        Datastorage instance = new Datastorage();
        String expResult = "";
        String result = instance.deleteMessageByHash(hash);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayMessageReport method, of class Datastorage.
     */
    @Test
    public void testDisplayMessageReport() {
        System.out.println("displayMessageReport");
        Datastorage instance = new Datastorage();
        instance.displayMessageReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSentMessages method, of class Datastorage.
     */
    @Test
    public void testGetSentMessages() {
        System.out.println("getSentMessages");
        Datastorage instance = new Datastorage();
        String[] expResult = null;
        String[] result = instance.getSentMessages();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessages method, of class Datastorage.
     */
    @Test
    public void testGetMessages() {
        System.out.println("getMessages");
        Datastorage instance = new Datastorage();
        String[] expResult = null;
        String[] result = instance.getMessages();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageHash method, of class Datastorage.
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("getMessageHash");
        Datastorage instance = new Datastorage();
        String[] expResult = null;
        String[] result = instance.getMessageHash();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.datastorage;

/**
 *
 * @author Siyanda
 */import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
public class Datastorage {
      // Arrays to store message data
    private String[] sentMessages;
    private String[] disregardedMessages;
    private String[] storedMessages;
    private String[] messageHash;
    private String[] messageID;
    
    // Parallel arrays for message details
    private String[] recipients;
    private String[] messages;
    private String[] flags;
    
    public Datastorage() {
        initializeArrays();
        populateTestData();
}

    public static void main(String[] args) {
        // Arrays to store message data
   
    }
    
    private void initializeArrays() {
        // Initialize arrays with size 5 for the test data
        sentMessages = new String[5];
        disregardedMessages = new String[5];
        storedMessages = new String[5];
        messageHash = new String[5];
        messageID = new String[5];
        
        recipients = new String[5];
        messages = new String[5];
        flags = new String[5];
    }
    
    private void populateTestData() {
        // Test Data Message 1
        recipients[0] = "+27834557896";
        messages[0] = "Did you get the cake?";
        flags[0] = "Sent";
        messageID[0] = "MSG001";
        messageHash[0] = generateHash(messages[0]);
        
        // Test Data Message 2
        recipients[1] = "+27838884567";
        messages[1] = "Where are you? You are late! I have asked you to be on time.";
        flags[1] = "Stored";
        messageID[1] = "MSG002";
        messageHash[1] = generateHash(messages[1]);
        
        // Test Data Message 3
        recipients[2] = "+27834484567";
        messages[2] = "Yohoooo, I am at your gate.";
        flags[2] = "Disregard";
        messageID[2] = "MSG003";
        messageHash[2] = generateHash(messages[2]);
        
        // Test Data Message 4
        recipients[3] = "0838884567";
        messages[3] = "It is dinner time!";
        flags[3] = "Sent";
        messageID[3] = "MSG004";
        messageHash[3] = generateHash(messages[3]);
        
        // Test Data Message 5
        recipients[4] = "+27838884567";
        messages[4] = "Ok, I am leaving without you.";
        flags[4] = "Stored";
        messageID[4] = "MSG005";
        messageHash[4] = generateHash(messages[4]);
        
        // Populate specialized arrays based on flags
        populateSpecializedArrays();
    }
    
    private void populateSpecializedArrays() {
        int sentIndex = 0, disregardIndex = 0, storedIndex = 0;
        
        for (int i = 0; i < messages.length; i++) {
            if (flags[i] != null) {
                switch (flags[i]) {
                    case "Sent":
                        sentMessages[sentIndex++] = messages[i];
                        break;
                    case "Disregard":
                        disregardedMessages[disregardIndex++] = messages[i];
                        break;
                    case "Stored":
                        storedMessages[storedIndex++] = messages[i];
                        break;
                }
            }
        }
    }
    
    private String generateHash(String message) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(message.getBytes());
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            
            return hexString.toString().substring(0, 16); // Shortened for readability
        } catch (NoSuchAlgorithmException e) {
            return "hash_" + Math.abs(message.hashCode());
        }
    }
    
    // Feature 2a: Display sender and recipient of all sent messages
    public void displaySentMessages() {
        System.out.println("=== SENT MESSAGES ===");
        for (int i = 0; i < flags.length; i++) {
            if ("Sent".equals(flags[i])) {
                System.out.println("To: " + recipients[i] + " | Message: " + messages[i]);
            }
        }
    }
    
    // Feature 2b: Display the longest sent message
    public String getLongestMessage() {
        String longestMessage = "";
        for (String message : messages) {
            if (message != null && message.length() > longestMessage.length()) {
                longestMessage = message;
            }
        }
        return longestMessage;
    }
    
    // Feature 2c: Search for message ID and display recipient and message
    public String searchMessageByID(String searchID) {
        for (int i = 0; i < messageID.length; i++) {
            if (searchID.equals(messageID[i])) {
                return "Recipient: " + recipients[i] + " | Message: " + messages[i];
            }
        }
        return "Message ID not found";
    }
    
    // Feature 2d: Search for all messages sent to a particular recipient
    public List<String> searchMessagesByRecipient(String recipient) {
        List<String> result = new ArrayList<>();
        for (int i = 0; i < recipients.length; i++) {
            if (recipient.equals(recipients[i]) && messages[i] != null) {
                result.add(messages[i]);
            }
        }
        return result;
    }
    
    // Feature 2e: Delete a message using message hash
    public String deleteMessageByHash(String hash) {
        for (int i = 0; i < messageHash.length; i++) {
            if (hash.equals(messageHash[i])) {
                String deletedMessage = messages[i];
                messages[i] = null;
                recipients[i] = null;
                flags[i] = null;
                messageID[i] = null;
                messageHash[i] = null;
                populateSpecializedArrays(); // Update specialized arrays
                return "Message \"" + deletedMessage + "\" successfully deleted.";
            }
        }
        return "Message hash not found";
    }
    
    // Feature 2f: Display report of all sent messages
    public void displayMessageReport() {
        System.out.println("=== MESSAGE REPORT ===");
        System.out.printf("%-20s %-15s %s%n", "Message Hash", "Recipient", "Message");
        System.out.println("------------------------------------------------------------");
        
        for (int i = 0; i < flags.length; i++) {
            if ("Sent".equals(flags[i]) && messages[i] != null) {
                System.out.printf("%-20s %-15s %s%n", 
                    messageHash[i], 
                    recipients[i], 
                    messages[i]);
            }
        }
    }
    
    // Getters for unit testing
    public String[] getSentMessages() {
        return Arrays.stream(sentMessages).filter(Objects::nonNull).toArray(String[]::new);
    }
    
    public String[] getMessages() {
        return messages;
    }
    
    public String[] getMessageHash() {
        return messageHash;
    }
}
    

